export default {
    ProductAPI:'https://dummyjson.com/products?limit=100'
}