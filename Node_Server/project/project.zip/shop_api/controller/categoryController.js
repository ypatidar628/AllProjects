import '../connection/dbConfig.js';
import categorySchemaModel from '../model/categoryModel.js'
import APIResponse from '../response/APIResponse.js';


export var saveCategory = async (req, res) => {

  // Data Get from Request Object 
  var categoryDetails = req.body;

  // All Data Get From Collection 
  const categoryListData = await categorySchemaModel.find();

  // Find length;
  var len = categoryListData.length;
  console.log("Category List Length : " + len);

  var _id = (len == 0) ? 1 : categoryListData[len - 1]._id + 1
  console.log("Id is : " + _id);

  categoryDetails = { ...categoryDetails, "_id": _id, };
  console.log("Category Object Is : " + JSON.stringify(categoryDetails));

  try {
    var resp = await categorySchemaModel.create(categoryDetails);


    res.status(200).json({ "status": true, "message": "Data Inserted Successfully...", "Category": resp });
  }
  catch (err) {
    console.log(" Category Exception is : " + err.message);
    res.status(500).json({ "status": false, "message": "Record Not Inserted", "error": err.message });
  }

}

export var viewAllCategory = async (req, res, next) => {
  // var userCategory = req.body;

  try {
    var categoryList = await categorySchemaModel.find();
    // console.log("all"+JSON.stringify(userDetails));

    var len = categoryList.length;
    if (len != 0) {

      res.status(200).json(new APIResponse(true, { category: categoryList }, "Category Data Found"));
    }
    else {
      res.status(401).json(new APIResponse(false, { category: categoryList }, "Category Data Not Found"));
    }
  }
  catch (err) {
    console.log("Category Data found Exception is : " + err);
  }
}

export var searchCategory = async (req, res, next) => {
  var { category_name } = req.body;

  try {
    var categoryList = await categorySchemaModel.findOne({ category_name });
    // console.log("all"+JSON.stringify(userDetails));

    var len = categoryList.length;
    if (len != 0) {
      res.status(200).json(new APIResponse(true, { category: categoryList }, "Category Data Found"));
    }
    else {
      res.status(401).json(new APIResponse(false, { category: categoryList }, "Category Data Not Found"));
    }
  }
  catch (err) {
    console.log("Category Data found Exception is : " + err);
  }
}

export var deleteCategory = async(req,res) =>{
  var {category_name} = req.body;
try{
  var categoryList = await categorySchemaModel.deleteOne({category_name});
  // var len = categoryList.length;
  if(categoryList)   //len != 0
  {
    return res.status(200).json(new APIResponse(true,{category:categoryList}, "Category Data Deleted"));
  }
  else
  {
  return res.status(404).json(new APIResponse(false,{},"Category Data Not Deleted"));      
  }
}
catch(err){
  console.log("Delete Category Exception is : "+err);
  return res.status(500).json(new APIResponse(false, {}, "Internal Server Error"));
}
}

export var updateCategory = async(req,res )=>{
  // var { oldCategoryName, newCategoryName } = req.body;

  const request_details = req.body;
    var oldCategoryName = request_details.oldCategoryName;
    var newCategoryName = request_details.newCategoryName;

try{
  var categoryList = await categorySchemaModel.updateOne(
    {category_name : oldCategoryName},
    {$set:{category_name : newCategoryName}});
  var len = categoryList.length;
  if(len != 0)
  {
    return res.status(200).json(new APIResponse(true,{category:categoryList}, "Category Data Updated"));
  }
  else
  {
  return res.status(404).json(new APIResponse(false,{},"Category Not Found"));      
  }
}
catch(err){
  console.log("Update Category Exception is : "+err);
  return res.status(500).json(new APIResponse(false, {}, "Internal Server Error"));
}
}