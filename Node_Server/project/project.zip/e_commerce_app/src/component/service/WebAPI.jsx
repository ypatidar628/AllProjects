export default {
    // User API
    saveUser : 'http://localhost:8989/user/saveUser',
    otpMatch : ' http://localhost:8989/user/OTPMatch',
    loginUser :'http://localhost:8989/user/loginUser',
    viewAllUser :'http://localhost:8989/user/viewAllUser',

    // Product API
    saveProduct : 'http://localhost:8989/product/saveProduct',
    viewAllProduct : 'http://localhost:8989/product/viewAllProduct',
    deleteProduct : 'http://localhost:8989/product/deleteProduct',
    
}