import axios from "axios";
class WebService {
    postAPICall(url,data){
        var result = axios.post(url,data)
        return result;
    }
    getAPICall(url,token){
        var result = axios.get(url, { headers: { Authorization: `Bearer ${token}` } })
        return result;
    }
    postAPICallWithToken(url, data, token) {
        var result = axios.post(url, data, { headers: { Authorization: `Bearer ${token}` } })
        return result;
    }
    deleteAPICall(url, token, data) {
        return axios.delete(url, {
          headers: { Authorization: `Bearer ${token}` },
          data: data // Must be provided like this
        });
      }
}

export default new WebService();