import React from 'react'
import Navbar from './component/comman/Navbar'
import { Route, Routes } from 'react-router-dom'
import Footer from './component/comman/Footer'
import Home from './component/comman/Home'
import Login from './component/index/Login'
import Register from './component/index/Register'
import Product from './component/admin/Product'
import About from './component/comman/About'
import Otp from './component/index/Otp'
import Contact from './component/comman/Contact'
import './App.css'
import UserController1 from './component/admin/UserController1'
import ProductCantroller from './component/admin/ProductController'

function App() {
  return<div>
    <Navbar/>
    <Routes>
      <Route path='/' element={<Home/>}></Route>
      <Route path='/about' element={<About/>}></Route>
      <Route path='/product' element={<Product/>}></Route>
      <Route path='/login' element={<Login/>}></Route> 
      <Route path='/contact' element={<Contact/>}></Route>
      <Route path='/register' element={<Register/>}></Route>
      <Route path='/otpMatch' element={<Otp/>}></Route>
      <Route path='/admin/allUser' element={<UserController1/>}></Route>
      <Route path='/admin/product' element={<ProductCantroller/>}></Route>
    </Routes>
    <Footer/>
    </div>
}

export default App